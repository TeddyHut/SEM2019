/*
* libmega328.h
*
* Created: 26/01/2019 06:18:00 PM
*  Author: teddy
*/

#pragma once

#include "libarduino_m328/iohardware.h"
