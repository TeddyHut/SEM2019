/*
 * metadata.cpp
 *
 * Created: 17/01/2019 4:11:06 AM
 *  Author: teddy
 */ 

#include "metadata.h"

uint8_t libmodule::module::metadata::com::Header[2] = {0x5E, 0x8A};
