/*
 * userio.cpp
 *
 * Created: 3/12/2018 3:58:28 PM
 *  Author: teddy
 */ 

#include "userio.h"
